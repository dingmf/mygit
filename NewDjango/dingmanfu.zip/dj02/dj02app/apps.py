from django.apps import AppConfig


class Dj02AppConfig(AppConfig):
    name = 'dj02app'

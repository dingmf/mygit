from django.apps import AppConfig


class Dj02ApppulsConfig(AppConfig):
    name = 'dj02apppuls'
